# jquery-ajax

jQuery built with command: `grunt custom:-css,-deprecated,-dimensions,-effects,-event,-offset,-wrap,-sizzle,-core/ready`.
